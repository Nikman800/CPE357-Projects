#ifndef UTIL_H
#define UTIL_H

void *checked_malloc(size_t size);

#endif
